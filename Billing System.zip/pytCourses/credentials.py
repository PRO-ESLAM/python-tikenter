# User Credentials
host = 'localhost'
user = 'your username here'
password = 'your password here'
database = 'student_database'