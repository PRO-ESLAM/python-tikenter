   
        # self.lbl_mob=Label(cust_F,text="Mobile : " ,font=("time new roman",12,"bold"),bg="#fff",fg="red")
        # self.lbl_mob.grid(row=0,column=0,sticky=W,padx=5,pady=2)
       
        # self.entry_mob=ttk.Entry(cust_F,font=("time new roman",12,"bold"),width=24)
        # self.entry_mob.grid(row=0,column=1)
